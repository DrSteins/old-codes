#!/usr/bin/env python
# coding: utf-8

import networkx as nx
import matplotlib.pyplot as plt
from docplex.mp.model import Model
import numpy as np
import pandas as pd
import os

def main():
    print('::: VRP - ejecutado correctamente :::')
    def secuencia(nodo):
        for i in nodos:
            if(nodo!=i):
                n = int(solucion.get_value(x[nodo,i]))
                if(n==1):
                    if(i==bodega[0]):
                        return []
                    else:
                        return [i] + secuencia(i)


    windows = pd.read_csv('constraints.csv')
    distance_time = pd.read_csv('time-distance-matrix.csv')


    bodega=[1,32400] #nodo que representa la bodega y tiempo en el cual los camiones salen de la misma



    nodos=windows["rr_id"].to_list()
    nodos = [bodega[0]] +nodos

    distances_and_times={}
    for i in distance_time.to_numpy():
        distances_and_times[i[0],i[1]] = i[2:]

    ventanas={bodega[0]:bodega[1]}
    for i in windows.to_numpy():
        ventanas[i[0]]= i[2:]

    n = len(nodos)
    s=20*60
    m = 50 #cantidad de vehiculos disponibles
    M = 99999999999999

    # ## Modelos matemático


    mdl = Model('VRP')

    # relative MIP gap tolerance
    mdl.parameters.mip.tolerances.mipgap=0.001;

    #VARIABLES
    x={}
    for i in nodos:
        for j in nodos:
            if(i != j):
                n1 = str(i)
                n2 = str(j)
                x[i,j] = mdl.binary_var(name='x_'+n1+"_"+n2)
            else:
                x[i,j]=0
                
    u={}
    for i in nodos:
        zz=str(i)
        u[i]=mdl.integer_var(name='u_'+zz)
        
    tr ={}
    for i in nodos:
        zz=str(i)
        tr[i]=mdl.continuous_var(name='tr_'+zz)

    #Eliminación de subtours
    for i in nodos[1:]:
        for j in nodos[1:]:
            if(i != j):
                mdl.add_constraint(u[i]-u[j]+n*x[i,j] <= n-1)

    #A cada nodo entra y sale sólo un vehiculo a lo mucho
    for j in nodos[1:]:
                mdl.add_constraint(mdl.sum(x[i,j] for i in nodos) == 1)
                mdl.add_constraint(mdl.sum(x[j,i] for i in nodos) == 1)
                
    mdl.add_constraint(mdl.sum(x[nodos[0],j] for j in nodos[1:]) <= m)

    #Ventanas de tiempo
    mdl.add_constraint(tr[nodos[0]] == ventanas[nodos[0]])

    for i in nodos[1:]:
        mdl.add_constraint(ventanas[i][0] <= tr[i])
        mdl.add_constraint(ventanas[i][1] >= tr[i]+s)

        
    for i in nodos:
        for j in nodos[1:]:
            if(i != j):
                mdl.add_constraint(tr[i]+s+distances_and_times[i,j][1] - M*(1-x[i,j]) <= tr[j]) 
                
    #mdl.minimize(mdl.sum(M*x[nodos[0],i] for i in nodos[1:]) )  

    mdl.minimize(mdl.sum(2*x[nodos[0],i] for i in nodos[1:]) + mdl.sum(2*x[i,nodos[0]] for i in nodos))

    solucion = mdl.solve()
    print(solucion)


    # ## Guardar archivo csv con los resultados

    rr_id = secuencia(bodega[0])
    orden=[]
    time_to_pickup=[]
    for i,nodo in enumerate(rr_id):
        orden.append(i+1)
        aa=solucion.get_value(tr[nodo])
        time_to_pickup.append(aa)
        
    salida ={
        "rr_id":rr_id,
        "orden":orden,
        "time_to_pickup":time_to_pickup  
    }
        
    entregable = pd.DataFrame(salida)
    entregable.to_csv("entregable_1.csv")


    # ## Grafo


    s={}
    for i in nodos:
        for j in nodos:
            if(i != j):
                s[i,j]= int(solucion.get_value(x[i,j]))
            else:
                s[i,j]=0
                
    g = nx.DiGraph()
    g.add_nodes_from(nodos)

    for i in nodos:
        for j in nodos:
            if(s[i,j]==1):
                g.add_edge(i,j)

    plt.figure(figsize=(5, 6), dpi=80)

    nx.draw(g,with_labels=True)

    plt.draw()
    plt.show()

if __name__ == '__main__':
    main()


