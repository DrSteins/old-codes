import csv
import sys
import requests
import os
import email
import smtplib
import ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from main import maping
import datetime

def send_email():
    
    subject = ".:: RUTA DE RECOLECCIONES ::.."


    body = """Les hago llegar el plan del día : {date},
              El link de la recoleccion: {link} """.format_map({'date' : datetime.datetime.now(),
                                                                'link': link})

    sender_email = "rpalbotemail@gmail.com"
    password = "yuoq cuam rpjr yweq"

    # Create a multipart message and set headers
    recipients = ['rpalbotemail@gmail.com',
                'alberto@raypal.com.mx',
                'isaac@raypal.com.mx']

    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = ", ".join(recipients)
    message["Subject"] = subject


    # Add body to email
    message.attach(MIMEText(body, "plain"))

    filename = "entregable_conductor.csv"  # In same directory as script

    # Open  file in binary mode
    with open(filename, "rb") as attachment:
        # Add file as application/octet-stream
        # Email client can usually download this automatically as attachment
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())

    # Encode file in ASCII characters to send by email
    encoders.encode_base64(part)

    # Add header as key/value pair to attachment part
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )

    # Add attachment to message and convert message to string
    message.attach(part)
    text = message.as_string()

    # Log in to server using secure context and send email
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, recipients, text)

def main():
    send_email()

if __name__ == "__main__":
    main()