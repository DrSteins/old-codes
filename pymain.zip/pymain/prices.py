import mpu
import pandas as pd
from pandas import DataFrame
import numpy as np

df = pd.read_csv('cp_ctd.csv')
raypal = (20.619651, -103.342885)

def calculate_distances(data):

    distance = []
    for i, row in data.iterrows():
        x = mpu.haversine_distance((row['X2'], row['X1']), (raypal))
        distance.append(x)
    df2 = DataFrame(distance, columns=['distance'])
    calculate_distances.distance = df2
    return df2

def calculate_prices():
    kmeters = calculate_distances.distance
    loss = 8.8 + (8.14*kmeters)
    cost = 50 + loss # lo que se cobra al cliente
    cost = cost.rename(columns={"distance": "cost"})
    print(cost)
    
    prices = pd.concat([df.reset_index(drop=True),
                        calculate_distances.distance,
                        cost], axis=1)
    prices = prices[['d_cp', 'distance', 'cost']].set_index('d_cp')
    prices.to_csv('cotizacion_cp.csv')
    return prices


def main():
    calculate_distances(df)
    calculate_prices()

if __name__ == '__main__':
    main()