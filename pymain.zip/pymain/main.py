# Raypal AI Recycling
# Este code funciona para calcular la matriz distancia tiempo.
# ----------------------------------------------------------------
#******************************************
# Copyright Proper
#******************************************
# Author: Kevin De Alba
# Creation Date: 2021-01-22
#__________________________________________
# Input: - guadalajara_network.graphml
# Output: - constrainst.csv, time-distance-matrix.csv
#__________________________________________
from os import write
import osmnx as ox
import networkx as nx
import pandas as pd
from itertools import permutations
import psycopg2
import io
from sqlalchemy import create_engine
from sqlalchemy import delete
import re
from datetime import datetime
import webbrowser
import vrp_1_3 # es el archivo del algortimo.
import smtplib
import ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Es el dia en el que queremos hacer el cálculo.
date = str(input("Introducir fecha (dd/mm/yyyy): "))



# Con esta funcion tomamos el mapa de nodos de GDL
def load_file(file, routepath):
    #Configure osmnx
    global G
    ox.config(log_console=True, use_cache=False)
    #Load the graph file of GDL
    G = ox.load_graphml('{}{}'.format(routepath, file))
    return G

#Nos conectamos a la db de raypal para tomar datos de las recolecciones.
def db_connect():
    global cur
    global records
    global col_names
    
        #Connect to the database
    conn = psycopg2.connect(database="raypal", user="raypal",
                            password="just4now", host="www.raypal.com.mx", port="5432")
    print("Opened database successfully")
    cur = conn.cursor()


    #Execute sql query to the scheme recollection_request
    cur.execute("""select distinct a.rr_id, ad.loc_lat, ad.loc_long
	from
	
        (select * from user_app
        ) c
	
	left join 
	
        (select * from address
        ) ad on c.id_user=ad.id_user
	
	left join 
	
        (select * from recollection_request where rr_status not in (5,4)
        
        ) a on c.id_user=a.id_user
	
	left join 
	
        (select * from scheduled_datetimes
        where sdate in ('{date_format}')
        ) b on a.rr_id=b.rr_id
	
	where a.rr_id is not null and b.hours is not null and a.rloc_lat between 20.3813189 
    and 20.901608 and a.rloc_long between -103.675077 and -102.991097
    and a.rloc_lat != 0 and a.rloc_long != 0
	order by a.rr_id desc
                        ;""".format_map({'date_format' : date}))
    print("Selecting rows from raypal table using cursor.fetchall")
    records = cur.fetchall()
    col_names = []
    for elt in cur.description:
        col_names.append(elt[0])
    print("Operation done successfully")


    conn.close()

    return col_names, records, cur

#Toma el query y lo manda a un dataframe
def data_frames():
    global df
    global df1
    db_connect()
    # df.to_csv('recollection_request.csv')
    df = pd.DataFrame(records, columns=col_names)
    print(df)
    return df

#Hace el calculo de nodos a partir del graph de gdl y las coordenadas de las recolecciones
def nodes_():
    global nodes
    global nodes_perm
    global permutation
    global perm
    global df
    #Select the route_id and the localization
    nodes = []
    for index, row in df.iterrows():
        a = ox.get_nearest_node(G, (row['loc_lat'], row['loc_long']))
        nodes.append(a)

    bodega = ox.get_nearest_node(G, (20.619651, -103.342885))
    depot = pd.DataFrame({"rr_id": [1],
                        "loc_lat": [20.619651],
                        "loc_long": [-103.342885],
                        "nearest_node": [bodega]
                        })
    nodes = pd.DataFrame(nodes, columns=['nearest_node'])
    df = pd.concat([df.reset_index(drop=True), nodes], axis=1)
    df = df.append(depot, ignore_index=True)
    df.to_csv('rr_id_test.csv')
    nearest_node = list(df.iloc[:, 3])
    df.to_csv('test2.csv')

    # Get all permutations of length 2
    permutation = []
    perm = permutations(nearest_node, 2)
    # Print the obtained permutations
    for i in list(perm):
        permutation.append(i)

    nodes_perm = pd.DataFrame(permutation, columns=[
                            'orig_node', 'target_node'])
    nodes_perm.to_csv('test3.csv')
    # nodes_perm.head()

    return nodes, nodes_perm, permutation, perm, df

# Calcula las distancias y tiempos para cada permutation.
def shortest_path_len():
    global length
    global r
    global df_distance
    global df

    nodes_()
    length = []
    time = []
    for index, row in nodes_perm.iterrows():
        r = nx.shortest_path_length(
            G=G, source=row['orig_node'], target=row['target_node'], 
            weight='length')
        d = r/1000 # en km
        t = (0.0004*d**3  - 0.0417*d**2 + 2.2618*d + 2.4319)*60 # t en secs
        length.append(r)
        time.append(t)

    #Add a column for the nodes permutated and add the distance in meters
    length = pd.DataFrame(length, columns=['length_m'])
    time_ = pd.DataFrame(time, columns=['time_s'])
    df_distance = pd.concat([nodes_perm.reset_index(drop=True), length, time_, df], axis=1)
    # df_distance = df_distance.dropna()
    print(df_distance.head())
    df_distance.to_csv('distance.csv')
 

    return df_distance, length, nodes_perm

# Escribe en la database los dataframes de la matriz
def update_table():
    from sqlalchemy import create_engine

    
    engine = create_engine('postgresql://raypal:just4now@www.raypal.com.mx:5432/raypal')
    
    df_distance.to_sql('distances_matrix1', engine, if_exists='replace')
    df.to_sql('table_node_rrid', engine, if_exists='replace')


# Ejecutamos el query final que nos dara la relacion de rrid para la distance matrix
def final_query():

    global cur
    global records
    global col_names

        #Connect to the database
    conn = psycopg2.connect(database="raypal", user="raypal",
                            password="just4now", host="www.raypal.com.mx", 
                            port="5432")
    print("Opened database successfully")
    cur = conn.cursor()


    #Execute sql query to the scheme recollection_request
    query = """ select origen.rr_id_origen, target.rr_id_target, 
			origen.length_m, origen.time_s
	from
	
	(select b.rr_id as rr_id_origen ,a.length_m ,a.time_s
	 from distances_matrix1 a
	 left join table_node_rrid b on a.orig_node = b.nearest_node
	) origen
	 
	left join 
	
	(select b.rr_id as rr_id_target ,a.length_m ,a.time_s
	 from distances_matrix1 a
	 left join table_node_rrid b on a.target_node = b.nearest_node
	) target on origen.length_m= target.length_m and origen.time_s=target.time_s """

    print("Selecting rows frm raypal table using cursor.fetchall")
    
    outputquery = 'copy ({0}) to stdout with csv header'.format(query)
    with open('time-distance-matrix.csv', 'w') as f:
        cur.copy_expert(outputquery, f)

    return

def time_window():
    global cur
    global records
    global col_names

        #Connect to the database
    conn = psycopg2.connect(database="raypal", user="raypal",
                            password="just4now", host="www.raypal.com.mx", 
                            port="5432")
    print("Opened database successfully")
    cur = conn.cursor()


    #Execute sql query to the scheme recollection_request
    cur.execute( """ select tas.rr_id, tas.sdate, tas.hours, tas.horario_min, tas.horario_max

from( select rr_id, a.sdate, a.hours, cast(substring(a.horario_min, 1, 2) as int) as horario_min, 
    cast(substring(a.horario_max, 1, 2) as int) as horario_max, substring(a.horario_min, 4, 5), 
    substring(a.horario_max, 4, 5)
        from

        (select distinct schedule.sdate, schedule.hours, schedule.rr_id, SPLIT_PART(schedule.hours, '-', 1) as horario_min ,SPLIT_PART(schedule.hours, '-', 2) horario_max
        from 
            (select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 1) hours
            from (select distinct sdate, hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 2) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
                
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 3) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 4) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 5) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            ) schedule
            where schedule.hours !='' and sdate in ('{date_format}') 
        ) a


        order by a.rr_id desc) tas
  
   left join
   
   (select * from recollection_request ) tes on tas.rr_id = tes.rr_id
   
  where rloc_lat !=0
 
 
      
        """.format_map({'date_format' : date}))
    print("Selecting rows frm raypal table using cursor.fetchall")
    
    records = cur.fetchall()
    col_names = []
    for elt in cur.description:
        col_names.append(elt[0])
    df_cons = pd.DataFrame(records, columns=col_names)
    df_cons = df_cons.drop(['horario_min', 'horario_max'], axis=1)
    print(df_cons)

    # Corregir el formato de hora.
    hrs = []
    hrs1 = []
    
    for i in range(0, len(df_cons)):
        time = re.split(' - | -|- ', df_cons['hours'][i])
        a = datetime.strptime(time[0], '%I %p').hour
        b = datetime.strptime(time[1], '%I %p').hour
        hrs.append(a)
        hrs1.append(b)
    
    df_min = pd.DataFrame(hrs)
    df_max = pd.DataFrame(hrs1)

    df_min.apply(lambda x: pd.Series(x[0])).stack().reset_index(level=1, drop=True)
    df_max.apply(lambda x: pd.Series(x[0])).stack().reset_index(level=1, drop=True)
   
    merged = pd.concat([df_cons, df_min, df_max], ignore_index=True, axis = 1)
    merged.columns = ['rr_id', 'sdate','na', 'horario_min', 'horario_max']
    merged['horario_min'] = 3600 * merged['horario_min']
    merged['horario_max'] = 3600 * merged['horario_max']
    merged.set_index('rr_id', inplace=True)
    merged = merged.drop(columns = ['na'])
   
    print(merged)

    #select max value
    merged_1 = merged.groupby('rr_id', as_index=True).max()
    merged_1 = merged_1.drop(columns = ['horario_min', 'sdate'])

    print(merged_1)
     #select min value
    merged_2 = merged.groupby('rr_id', as_index=True).min()
    merged_2 = merged_2.drop(columns = ['horario_max'])
    
    print(merged_2)


    d3 = pd.concat([merged_2, merged_1], axis = 1)
    d3.to_csv('constraints.csv') #data frame corregido, constraints unicos
    print(d3)
    print("Operation done successfully")
    conn.close()
    return

# maping() deber correr despues de la ejecucion del algortimo
def maping():
    global link
    global cur
    global df2
    global waypoints
    global records
    global col_names
    global data_frame
    global rr_id_order

        #Connect to the database
    conn = psycopg2.connect(database="raypal", user="raypal",
                            password="just4now", host="www.raypal.com.mx", port="5432")
    print("Opened database successfully")


    #Execute sql query to the scheme recollection_request
    sql = """ select a.rr_id, c.name, ad.address, ad.loc_lat, ad.loc_long,
		   b.sdate as schedule_date
                     from
                     
                     (select * from user_app 
                     ) c
                     
                     left join 
                     
                     (select * from address 
                     ) ad on c.id_user=ad.id_user
                     
                     left join 
                     
                     (select * from recollection_request where 
                     rr_status not in (5,4) 
                     
                     ) a on c.id_user=a.id_user
                     
                     left join 
                     
                     (select * from scheduled_datetimes
                     where sdate in ('{date_format}') 
                     ) b on a.rr_id=b.rr_id
                     
                     where a.rr_id is not null and b.hours is not null
                     order by a.rr_id DESC
        """.format_map({'date_format' : date})

    # print("Selecting rows frm raypal table using cursor.fetchall")
    
    df_map = pd.read_sql_query(sql, conn)
    df_map.set_index("rr_id", inplace=True)
    df_map.reset_index()
    conn = None
    
    data_frame = pd.read_csv('entregable_1.csv')
    
    # Reordena el rr_id segun el algortimo.
    rr_id_order = data_frame['rr_id'].to_list()
    df2 = df_map.reindex(rr_id_order)
    # print(df2)

    raypal = "20.61967,-103.34281"
    route = """https://www.google.com/maps/dir/?api=1&origin={dir_0}&destination={dir_1}&waypoints=""".format(dir_0 = raypal,
                                              dir_1 = raypal)
    waypoints = [i for i in df2['address']]
    res = '%7C'.join(waypoints)
    link = route + res
    link = link.replace(" ", "+")
    link = link.replace(".,", ".")
    webbrowser.open(link)

    #assign objects
    maping.df = df2
    maping.wp = waypoints
    
    return (link, date, df2, waypoints)
maping()

def csv_2_driver():
    global cur
    global records
    global col_names
    global data_frame

        #Connect to the database
    conn = psycopg2.connect(database="raypal", user="raypal",
                            password="just4now", host="www.raypal.com.mx", port="5432")
    print("Opened database successfully")
    cur = conn.cursor()


    #Execute sql query to the scheme recollection_request
    sql = """ select distinct a.rr_id, c.id_user, c.name, c.email, a.comments, c.cellphone , ad.address, a.other_address, ad.loc_lat, ad.loc_long,
		   b.sdate as schedule_date, b.hours
	from
	
	(select * from user_app
	) c
	
	left join 
	
	(select * from address
	) ad on c.id_user=ad.id_user
	
	left join 
	
	(select * from recollection_request where rr_status not in (5,4) --and rr_id in (1357,1358,1356,1349)
	 
	) a on c.id_user=a.id_user
	
	left join 
	
	(select * from scheduled_datetimes
	 where sdate in ('{date_format}') 
	) b on a.rr_id=b.rr_id
	
	where a.rr_id is not null and b.hours is not null
	order by a.rr_id desc
        """.format_map({'date_format' : date})

    print("Selecting rows frm raypal table using cursor.fetchall")
    
    df_driver = pd.read_sql_query(sql, conn)
    
    rr_id_order = data_frame['rr_id'].to_list()
    df_driver = df_driver.reindex(rr_id_order)
    df_driver.to_csv('entregable_conductor.csv')
    conn = None

def send_email():
        
    subject = ".:: CORREO DE PRUEBA, (IGNORAR)::.."


    body = """Les hago llegar el plan del día : {date},
              El link de la recoleccion: {link} """.format_map({'date' : date,
                                                                'link': link})

    sender_email = "rpalbotemail@gmail.com"
    password = "yuoq cuam rpjr yweq"

    # Create a multipart message and set headers
    recipients = ['killbasterds7@gmail.com']

    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = ", ".join(recipients)
    message["Subject"] = subject


    # Add body to email
    message.attach(MIMEText(body, "plain"))

    filename = "entregable_conductor.csv"  # In same directory as script

    # Open  file in binary mode
    with open(filename, "rb") as attachment:
        # Add file as application/octet-stream
        # Email client can usually download this automatically as attachment
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())

    # Encode file in ASCII characters to send by email
    encoders.encode_base64(part)

    # Add header as key/value pair to attachment part
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )

    # Add attachment to message and convert message to string
    message.attach(part)
    text = message.as_string()

    # Log in to server using secure context and send email
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, recipients, text)


def main():

    load_file('guadalajara_network.graphml',
            '/home/dealba/Documents/Work/logisticodes/pymain/') # write your file folder
    data_frames()
    shortest_path_len()
    update_table()
    final_query()
    time_window()
    vrp_1_3.main()
    maping()
    csv_2_driver()
    send_email()


if __name__ == '__main__':
    main()
