
def main():
    print('::: VRP_Archivo de control ejecutado correctamente :::')

if __name__ == '__main__':
    main()